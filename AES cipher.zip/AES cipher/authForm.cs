﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace AES_cipher
{
    public partial class authForm : Form
    {
        AppContext db;

        public authForm()
        {
            InitializeComponent();
            db = new AppContext();
            List<User> users = db.Users.ToList();
            List<Record> records = db.Records.ToList();
        }

        private void authForm_Load(object sender, EventArgs e)
        {
            this.Text = "Authorization";
            //this.DesktopLocation = new Point(Screen.PrimaryScreen.Bounds.Width / 2 - (this.Width / 2), Screen.PrimaryScreen.Bounds.Height / 2 - (this.Height / 2));
        }

        private void SignInButton_Click(object sender, EventArgs e)
        {
            if ((authLog.Text == "") || (authPas.Text == ""))
            {
                ErrorLabel.Text = "Please fill in all fields";
                ErrorLabel.Visible = true;
            }
            else
            {
                ErrorLabel.Visible = false;
                List<User> users = db.Users.ToList();
                MD5 md5 = new MD5();
                bool authorized = false;
                mainForm main = null;
                foreach(var us in users)
                {
                    if ((us.Login == authLog.Text) && (us.Password == md5.digest(authPas.Text + "+" + authLog.Text))) { authorized = true; main = new mainForm(us.id); }
                }

                if (authorized) { main.Show(); }
                else { ErrorLabel.Text = "Incorrect login or password"; ErrorLabel.Visible = true; }
            }
        }

        private void authSignUpBut_Click(object sender, EventArgs e)
        {
            regForm reg = new regForm();
            reg.Show();
            this.Hide();
        }


    }
}
