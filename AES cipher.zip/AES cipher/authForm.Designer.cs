﻿
namespace AES_cipher
{
    partial class authForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(authForm));
            this.SignInButton = new System.Windows.Forms.Button();
            this.authPas = new System.Windows.Forms.TextBox();
            this.authLog = new System.Windows.Forms.TextBox();
            this.authSignUpBut = new System.Windows.Forms.Button();
            this.pasLabel = new System.Windows.Forms.Label();
            this.logLabel = new System.Windows.Forms.Label();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // SignInButton
            // 
            this.SignInButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(65)))), ((int)(((byte)(69)))));
            this.SignInButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SignInButton.Font = new System.Drawing.Font("Bookman Old Style", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SignInButton.ForeColor = System.Drawing.Color.Black;
            this.SignInButton.Location = new System.Drawing.Point(166, 250);
            this.SignInButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SignInButton.Name = "SignInButton";
            this.SignInButton.Size = new System.Drawing.Size(118, 41);
            this.SignInButton.TabIndex = 3;
            this.SignInButton.Text = "Sign in";
            this.SignInButton.UseVisualStyleBackColor = false;
            this.SignInButton.Click += new System.EventHandler(this.SignInButton_Click);
            // 
            // authPas
            // 
            this.authPas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(65)))), ((int)(((byte)(69)))));
            this.authPas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.authPas.Font = new System.Drawing.Font("Bookman Old Style", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.authPas.ForeColor = System.Drawing.Color.Black;
            this.authPas.Location = new System.Drawing.Point(111, 151);
            this.authPas.MaxLength = 32;
            this.authPas.Multiline = true;
            this.authPas.Name = "authPas";
            this.authPas.PasswordChar = '*';
            this.authPas.Size = new System.Drawing.Size(252, 28);
            this.authPas.TabIndex = 4;
            // 
            // authLog
            // 
            this.authLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(65)))), ((int)(((byte)(69)))));
            this.authLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.authLog.Font = new System.Drawing.Font("Bookman Old Style", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.authLog.ForeColor = System.Drawing.Color.Black;
            this.authLog.Location = new System.Drawing.Point(112, 84);
            this.authLog.MaxLength = 16;
            this.authLog.Multiline = true;
            this.authLog.Name = "authLog";
            this.authLog.Size = new System.Drawing.Size(252, 28);
            this.authLog.TabIndex = 5;
            // 
            // authSignUpBut
            // 
            this.authSignUpBut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(65)))), ((int)(((byte)(69)))));
            this.authSignUpBut.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.authSignUpBut.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.authSignUpBut.ForeColor = System.Drawing.Color.Black;
            this.authSignUpBut.Location = new System.Drawing.Point(315, 12);
            this.authSignUpBut.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.authSignUpBut.Name = "authSignUpBut";
            this.authSignUpBut.Size = new System.Drawing.Size(127, 33);
            this.authSignUpBut.TabIndex = 8;
            this.authSignUpBut.Text = "Sign up";
            this.authSignUpBut.UseVisualStyleBackColor = false;
            this.authSignUpBut.Click += new System.EventHandler(this.authSignUpBut_Click);
            // 
            // pasLabel
            // 
            this.pasLabel.AutoSize = true;
            this.pasLabel.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pasLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.pasLabel.Location = new System.Drawing.Point(109, 134);
            this.pasLabel.Name = "pasLabel";
            this.pasLabel.Size = new System.Drawing.Size(75, 16);
            this.pasLabel.TabIndex = 10;
            this.pasLabel.Text = "Password:";
            // 
            // logLabel
            // 
            this.logLabel.AutoSize = true;
            this.logLabel.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.logLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.logLabel.Location = new System.Drawing.Point(109, 67);
            this.logLabel.Name = "logLabel";
            this.logLabel.Size = new System.Drawing.Size(51, 16);
            this.logLabel.TabIndex = 11;
            this.logLabel.Text = "Login:";
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ErrorLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(130)))), ((int)(((byte)(130)))));
            this.ErrorLabel.Location = new System.Drawing.Point(111, 214);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(252, 23);
            this.ErrorLabel.TabIndex = 12;
            this.ErrorLabel.Text = "if something go wrong";
            this.ErrorLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ErrorLabel.Visible = false;
            // 
            // authForm
            // 
            this.AcceptButton = this.SignInButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(36)))));
            this.ClientSize = new System.Drawing.Size(455, 308);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.logLabel);
            this.Controls.Add(this.pasLabel);
            this.Controls.Add(this.authSignUpBut);
            this.Controls.Add(this.authLog);
            this.Controls.Add(this.authPas);
            this.Controls.Add(this.SignInButton);
            this.Font = new System.Drawing.Font("Bookman Old Style", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(475, 350);
            this.MinimumSize = new System.Drawing.Size(475, 350);
            this.Name = "authForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "authForm";
            this.Load += new System.EventHandler(this.authForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button SignInButton;
        private System.Windows.Forms.Button authSignUpBut;
        private System.Windows.Forms.Label pasLabel;
        private System.Windows.Forms.Label logLabel;
        private System.Windows.Forms.TextBox authPas;
        private System.Windows.Forms.TextBox authLog;
        private System.Windows.Forms.Label ErrorLabel;
    }
}