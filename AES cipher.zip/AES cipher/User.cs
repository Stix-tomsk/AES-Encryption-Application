﻿namespace AES_cipher
{
    class User
    {
        public int id { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }


        public User() { }
        public User(string log, string pas)
        {
            Login = log; Password = pas;
        }
    }
}
