﻿using System;
using System.Windows.Forms;

namespace AES_cipher
{
    public partial class mainForm : Form
    {
        AppContext db;
        int userId { get; set; }
        public mainForm(int id)
        {
            InitializeComponent();
            db = new AppContext();
            userId = id;
        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            this.Text = "AES Cipher";
        }

        private void EncryptButton_Click(object sender, EventArgs e)
        {
            string text = textForCrypt.Text;
            string stringKey = keyText.Text;

            AES128 aes = new AES128();
            string cryptedText = aes.encrypt(text, stringKey);
            if (cryptedText.Length > 256) { processedText.ScrollBars = ScrollBars.Vertical; }
            else { processedText.ScrollBars = ScrollBars.None; }
            processedText.Text = cryptedText;

            Record record = new Record(userId, processedText.Text);
            db.Records.Add(record);
            db.SaveChanges();

        }

        private void DescryptButton_Click(object sender, EventArgs e)
        {
            string text = textForCrypt.Text;
            string stringKey = keyText.Text;

            AES128 aes = new AES128();
            processedText.Text = aes.decrypt(text, stringKey);
        }

        private void authSignOutBut_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
