﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;

namespace AES_cipher
{
    public partial class regForm : Form
    {
        AppContext db;
        public regForm()
        {
            InitializeComponent();
            db = new AppContext();
        }

        private void regForm_Load(object sender, EventArgs e)
        {
            this.Text = "Registration";

        }

        private void SignUpButton_Click(object sender, EventArgs e)
        {
            if ((regLog.Text == "") || (regPas.Text == ""))
            {
                ErrorLabel.Text = "Please fill in all fields";
                ErrorLabel.Visible = true;
            }
            else if (PasConfirm.Text != regPas.Text)
            {
                ErrorLabel.Text = "Password mismatch";
                ErrorLabel.Visible = true;
            }
            else
            {
                List<User> users = db.Users.ToList();
                foreach(var us in users)
                    if (regLog.Text == us.Login) { ErrorLabel.Text = "User already exist"; ErrorLabel.Visible = true; return; }
                ErrorLabel.Visible = false;
                MD5 md5 = new MD5();
                User user = new User(regLog.Text, md5.digest(regPas.Text+"+"+regLog.Text));
                db.Users.Add(user);
                db.SaveChanges();

                authForm auth = new authForm();
                auth.Show();
                this.Hide();
            }
        }
    }
}
