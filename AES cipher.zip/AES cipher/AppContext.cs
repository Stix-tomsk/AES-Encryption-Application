﻿using System.Data.Entity;

namespace AES_cipher
{
    class AppContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Record> Records { get; set; }


        public AppContext() : base("DefaultConnection") { }
    }
}
