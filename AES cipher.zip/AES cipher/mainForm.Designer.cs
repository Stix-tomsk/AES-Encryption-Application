﻿
namespace AES_cipher
{
    partial class mainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainForm));
            this.logLabel = new System.Windows.Forms.Label();
            this.textForCrypt = new System.Windows.Forms.TextBox();
            this.processedText = new System.Windows.Forms.TextBox();
            this.keyText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.EncryptButton = new System.Windows.Forms.Button();
            this.DescryptButton = new System.Windows.Forms.Button();
            this.authSignOutBut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // logLabel
            // 
            this.logLabel.AutoSize = true;
            this.logLabel.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.logLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.logLabel.Location = new System.Drawing.Point(12, 40);
            this.logLabel.Name = "logLabel";
            this.logLabel.Size = new System.Drawing.Size(43, 16);
            this.logLabel.TabIndex = 12;
            this.logLabel.Text = "Text:";
            // 
            // textForCrypt
            // 
            this.textForCrypt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(65)))), ((int)(((byte)(69)))));
            this.textForCrypt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textForCrypt.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textForCrypt.ForeColor = System.Drawing.Color.Black;
            this.textForCrypt.Location = new System.Drawing.Point(15, 59);
            this.textForCrypt.MaxLength = 4096;
            this.textForCrypt.Multiline = true;
            this.textForCrypt.Name = "textForCrypt";
            this.textForCrypt.Size = new System.Drawing.Size(208, 135);
            this.textForCrypt.TabIndex = 13;
            // 
            // processedText
            // 
            this.processedText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(65)))), ((int)(((byte)(69)))));
            this.processedText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.processedText.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.processedText.ForeColor = System.Drawing.Color.Black;
            this.processedText.Location = new System.Drawing.Point(265, 134);
            this.processedText.MaxLength = 4096;
            this.processedText.Multiline = true;
            this.processedText.Name = "processedText";
            this.processedText.ReadOnly = true;
            this.processedText.Size = new System.Drawing.Size(182, 135);
            this.processedText.TabIndex = 14;
            // 
            // keyText
            // 
            this.keyText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(65)))), ((int)(((byte)(69)))));
            this.keyText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.keyText.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.keyText.ForeColor = System.Drawing.Color.Black;
            this.keyText.Location = new System.Drawing.Point(265, 59);
            this.keyText.MaxLength = 48;
            this.keyText.Multiline = true;
            this.keyText.Name = "keyText";
            this.keyText.Size = new System.Drawing.Size(182, 43);
            this.keyText.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.label1.Location = new System.Drawing.Point(262, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 16);
            this.label1.TabIndex = 16;
            this.label1.Text = "Key:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.label2.Location = new System.Drawing.Point(262, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 16);
            this.label2.TabIndex = 17;
            this.label2.Text = "Processed Text:";
            // 
            // EncryptButton
            // 
            this.EncryptButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(65)))), ((int)(((byte)(69)))));
            this.EncryptButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EncryptButton.Font = new System.Drawing.Font("Bookman Old Style", 10F, System.Drawing.FontStyle.Bold);
            this.EncryptButton.ForeColor = System.Drawing.Color.Black;
            this.EncryptButton.Location = new System.Drawing.Point(15, 212);
            this.EncryptButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.EncryptButton.Name = "EncryptButton";
            this.EncryptButton.Size = new System.Drawing.Size(100, 31);
            this.EncryptButton.TabIndex = 18;
            this.EncryptButton.Text = "Encrypt";
            this.EncryptButton.UseVisualStyleBackColor = false;
            this.EncryptButton.Click += new System.EventHandler(this.EncryptButton_Click);
            // 
            // DescryptButton
            // 
            this.DescryptButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(65)))), ((int)(((byte)(69)))));
            this.DescryptButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.DescryptButton.Font = new System.Drawing.Font("Bookman Old Style", 10F, System.Drawing.FontStyle.Bold);
            this.DescryptButton.ForeColor = System.Drawing.Color.Black;
            this.DescryptButton.Location = new System.Drawing.Point(123, 212);
            this.DescryptButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DescryptButton.Name = "DescryptButton";
            this.DescryptButton.Size = new System.Drawing.Size(100, 31);
            this.DescryptButton.TabIndex = 19;
            this.DescryptButton.Text = "Decrypt";
            this.DescryptButton.UseVisualStyleBackColor = false;
            this.DescryptButton.Click += new System.EventHandler(this.DescryptButton_Click);
            // 
            // authSignOutBut
            // 
            this.authSignOutBut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(65)))), ((int)(((byte)(69)))));
            this.authSignOutBut.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.authSignOutBut.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.authSignOutBut.ForeColor = System.Drawing.Color.Black;
            this.authSignOutBut.Location = new System.Drawing.Point(351, 12);
            this.authSignOutBut.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.authSignOutBut.Name = "authSignOutBut";
            this.authSignOutBut.Size = new System.Drawing.Size(96, 27);
            this.authSignOutBut.TabIndex = 20;
            this.authSignOutBut.Text = "Sign out";
            this.authSignOutBut.UseVisualStyleBackColor = false;
            this.authSignOutBut.Click += new System.EventHandler(this.authSignOutBut_Click);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(36)))));
            this.ClientSize = new System.Drawing.Size(459, 312);
            this.Controls.Add(this.authSignOutBut);
            this.Controls.Add(this.DescryptButton);
            this.Controls.Add(this.EncryptButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.keyText);
            this.Controls.Add(this.processedText);
            this.Controls.Add(this.textForCrypt);
            this.Controls.Add(this.logLabel);
            this.Font = new System.Drawing.Font("Bookman Old Style", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(479, 354);
            this.MinimumSize = new System.Drawing.Size(479, 354);
            this.Name = "mainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.mainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label logLabel;
        private System.Windows.Forms.TextBox textForCrypt;
        private System.Windows.Forms.TextBox processedText;
        private System.Windows.Forms.TextBox keyText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button EncryptButton;
        private System.Windows.Forms.Button DescryptButton;
        private System.Windows.Forms.Button authSignOutBut;
    }
}

