﻿
namespace AES_cipher
{
    partial class regForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(regForm));
            this.regLog = new System.Windows.Forms.TextBox();
            this.logLabel = new System.Windows.Forms.Label();
            this.regPas = new System.Windows.Forms.TextBox();
            this.pasLabel = new System.Windows.Forms.Label();
            this.PasConfirm = new System.Windows.Forms.TextBox();
            this.confirmPasLabel = new System.Windows.Forms.Label();
            this.SignUpButton = new System.Windows.Forms.Button();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // regLog
            // 
            this.regLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(65)))), ((int)(((byte)(69)))));
            this.regLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.regLog.Font = new System.Drawing.Font("Bookman Old Style", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.regLog.ForeColor = System.Drawing.Color.Black;
            this.regLog.Location = new System.Drawing.Point(111, 68);
            this.regLog.MaxLength = 16;
            this.regLog.Multiline = true;
            this.regLog.Name = "regLog";
            this.regLog.Size = new System.Drawing.Size(252, 28);
            this.regLog.TabIndex = 6;
            // 
            // logLabel
            // 
            this.logLabel.AutoSize = true;
            this.logLabel.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.logLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.logLabel.Location = new System.Drawing.Point(109, 51);
            this.logLabel.Name = "logLabel";
            this.logLabel.Size = new System.Drawing.Size(51, 16);
            this.logLabel.TabIndex = 12;
            this.logLabel.Text = "Login:";
            // 
            // regPas
            // 
            this.regPas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(65)))), ((int)(((byte)(69)))));
            this.regPas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.regPas.Font = new System.Drawing.Font("Bookman Old Style", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.regPas.ForeColor = System.Drawing.Color.Black;
            this.regPas.Location = new System.Drawing.Point(111, 120);
            this.regPas.MaxLength = 32;
            this.regPas.Multiline = true;
            this.regPas.Name = "regPas";
            this.regPas.PasswordChar = '*';
            this.regPas.Size = new System.Drawing.Size(252, 28);
            this.regPas.TabIndex = 13;
            // 
            // pasLabel
            // 
            this.pasLabel.AutoSize = true;
            this.pasLabel.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pasLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.pasLabel.Location = new System.Drawing.Point(109, 103);
            this.pasLabel.Name = "pasLabel";
            this.pasLabel.Size = new System.Drawing.Size(75, 16);
            this.pasLabel.TabIndex = 14;
            this.pasLabel.Text = "Password:";
            // 
            // PasConfirm
            // 
            this.PasConfirm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(65)))), ((int)(((byte)(69)))));
            this.PasConfirm.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.PasConfirm.Font = new System.Drawing.Font("Bookman Old Style", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PasConfirm.Location = new System.Drawing.Point(111, 176);
            this.PasConfirm.MaxLength = 32;
            this.PasConfirm.Multiline = true;
            this.PasConfirm.Name = "PasConfirm";
            this.PasConfirm.PasswordChar = '*';
            this.PasConfirm.Size = new System.Drawing.Size(252, 28);
            this.PasConfirm.TabIndex = 15;
            // 
            // confirmPasLabel
            // 
            this.confirmPasLabel.AutoSize = true;
            this.confirmPasLabel.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.confirmPasLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
            this.confirmPasLabel.Location = new System.Drawing.Point(109, 157);
            this.confirmPasLabel.Name = "confirmPasLabel";
            this.confirmPasLabel.Size = new System.Drawing.Size(134, 16);
            this.confirmPasLabel.TabIndex = 16;
            this.confirmPasLabel.Text = "Confirm password:";
            // 
            // SignUpButton
            // 
            this.SignUpButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(65)))), ((int)(((byte)(69)))));
            this.SignUpButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SignUpButton.Font = new System.Drawing.Font("Bookman Old Style", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SignUpButton.ForeColor = System.Drawing.Color.Black;
            this.SignUpButton.Location = new System.Drawing.Point(166, 250);
            this.SignUpButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.SignUpButton.Name = "SignUpButton";
            this.SignUpButton.Size = new System.Drawing.Size(118, 41);
            this.SignUpButton.TabIndex = 17;
            this.SignUpButton.Text = "Sign up";
            this.SignUpButton.UseVisualStyleBackColor = false;
            this.SignUpButton.Click += new System.EventHandler(this.SignUpButton_Click);
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ErrorLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(130)))), ((int)(((byte)(130)))));
            this.ErrorLabel.Location = new System.Drawing.Point(108, 213);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(252, 23);
            this.ErrorLabel.TabIndex = 18;
            this.ErrorLabel.Text = "if something go wrong";
            this.ErrorLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ErrorLabel.Visible = false;
            // 
            // regForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(36)))));
            this.ClientSize = new System.Drawing.Size(455, 308);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.SignUpButton);
            this.Controls.Add(this.confirmPasLabel);
            this.Controls.Add(this.PasConfirm);
            this.Controls.Add(this.pasLabel);
            this.Controls.Add(this.regPas);
            this.Controls.Add(this.logLabel);
            this.Controls.Add(this.regLog);
            this.Font = new System.Drawing.Font("Bookman Old Style", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(475, 350);
            this.MinimumSize = new System.Drawing.Size(475, 350);
            this.Name = "regForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "regForm";
            this.Load += new System.EventHandler(this.regForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox regLog;
        private System.Windows.Forms.Label logLabel;
        private System.Windows.Forms.TextBox regPas;
        private System.Windows.Forms.Label pasLabel;
        private System.Windows.Forms.TextBox PasConfirm;
        private System.Windows.Forms.Label confirmPasLabel;
        private System.Windows.Forms.Button SignUpButton;
        private System.Windows.Forms.Label ErrorLabel;
    }
}